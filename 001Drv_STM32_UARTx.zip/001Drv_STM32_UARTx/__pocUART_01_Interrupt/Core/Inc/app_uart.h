/*
 * app_uart.h
 *
 *  Created on: Oct 1, 2024
 *      Author: Rishabh.Srivastava
 */

#ifndef INC_APP_UART_H_
#define INC_APP_UART_H_



#endif /* INC_APP_UART_H_ */
