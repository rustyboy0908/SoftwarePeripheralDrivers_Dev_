/*
 * it.h
 *
 *  Created on: Oct 1, 2024
 *      Author: Rishabh.Srivastava
 */

#ifndef INC_IT_H_
#define INC_IT_H_

void USART2_IRQHandler(void);

#endif /* INC_IT_H_ */
