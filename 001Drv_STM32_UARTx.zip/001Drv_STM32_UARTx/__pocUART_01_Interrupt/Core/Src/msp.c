/*
 * msp.c
 *
 *  Created on: Oct 1, 2024
 *      Author: Rishabh.Srivastava
 */


#include "stm32g0xx_hal_cortex.h"
#include "stm32g0xx_hal_uart.h"

void HAL_MspInit()
{
	//Here we will do Descrete level Processor Specific inits
	// 	1.  Setup the priority grouping of ARM Cortex MX Processor.
	//	   HAL_NVIC_SetPriorityGrouping(xx,xx);

	//	2. Enable the required system exception of the arm cortex MX processor.

	//?? NA//SCB->SHCSR |= 0x7 <<16 ; //Memory Manager, BusFault, UsageFault...)

	//	3. Configure Priority of the system Exceptions.
	//?? NA//HAL_NVIC_SetPriority(N, PreemptPriority, SubPriority);
}

void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
	// ToDo: Configure the DrvLvL Registers(PinMuxing, Clock(RCC), Interrupts/NVIC Priority Settings)

	// Activity 1: Enable the clock for the UART2 Peripherals and GPIO
	__HAL_RCC_USART2_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	/* Activity 2: PinMuxing--> Pin Identified for USART2-------           (PA2(TX) and PA3(RX))
	                            Mode Identified as Alternative Function--- AF7       */

	GPIO_InitTypeDef gpio_uart2;
	// Mapping of Uart Transmission Pin --> PA2--> AF1
	gpio_uart2.Pin  		= 	GPIO_PIN_2;
	gpio_uart2.Mode 		= 	GPIO_MODE_AF_PP;
	gpio_uart2.Pull			= 	GPIO_PULLUP;
	gpio_uart2.Speed		=	GPIO_SPEED_FREQ_LOW;
	gpio_uart2.Alternate	=	GPIO_AF1_USART2;

	// Final Mapping of TX Pin to Alternate Function with Desired Peripherals.
	HAL_GPIO_Init(GPIOA, &gpio_uart2);

	// Mapping of Uart Transmission Pin --> PA3--> AF1
	gpio_uart2.Pin  		= 	GPIO_PIN_3;

	// Final Mapping of RX Pin to Alternate Function with Desired Peripherals.
	HAL_GPIO_Init(GPIOA, &gpio_uart2);

	/*Activity 3: Enable IRQ and NVIC Priority.*/

	// enabling NVIC vector number to the UART peripherals from the processor file.

	HAL_NVIC_EnableIRQ(USART2_IRQn);

	// Setting Priority of the IRQ number.

	HAL_NVIC_SetPriority(USART2_IRQn,15,0);

}
