/*
 * it.c
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */

void SysTick_Handler(void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();

}
