/*
 * app_uart.h
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */

#ifndef INC_APP_UART_H_
#define INC_APP_UART_H_

#include "stm32g0xx_hal_uart.h"
#include "stm32g071xx.h"

//UART_HandleTypeDef terminal_UART;
//
//void UART2_init(void);


#endif /* INC_APP_UART_H_ */
