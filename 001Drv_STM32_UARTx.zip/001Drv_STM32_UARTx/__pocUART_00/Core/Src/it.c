/*
 * it.c
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */
#include "boilerPlateHeader.h"

extern UART_HandleTypeDef terminal_UART;
void SysTick_Handler(void)
{
	HAL_IncTick();
	HAL_SYSTICK_IRQHandler();

}

void USART2_IRQHandler(void)
{

	//HAL_UART_IRQHandler(&terminal_UART);
	//HAL_UARTEx_RxEventCallback(&terminal_UART, 128);
}
