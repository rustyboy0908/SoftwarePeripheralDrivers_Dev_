/*
 * main.c
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */
#include "boilerPlateHeader.h"
#include "main.h"

//Function Declarations
void SystemClockConfig(void);

/*UART Function*/
void UART2_Init(void);

UART_HandleTypeDef terminal_UART;
char* data ="This is Application Code!!\r\n";
uint32_t reception_Count=0;
uint8_t receive_Data;
uint32_t count=0	;
uint8_t	dataBuffer_R[100];
uint16_t buffsize=16;


int main(void)
{
	// Initializes all the Discrete Level Inits of Microcontroller.
	// (We have done it for Systick)
	HAL_Init();
	SystemClockConfig();

	UART2_Init();
	uint32_t len= strlen(data);
	HAL_UART_Transmit(&terminal_UART, (uint8_t*)data, len, HAL_MAX_DELAY);

	while(1)
	{
		HAL_UART_Receive(&terminal_UART, &receive_Data,1, HAL_MAX_DELAY);
		if(receive_Data == '\r')
		{
			dataBuffer_R[count++] = '\n';
			dataBuffer_R[count++] = '\r';
			HAL_UART_Transmit(&terminal_UART, (uint8_t*)dataBuffer_R, count, HAL_MAX_DELAY);
			memset(dataBuffer_R,0,100);
			count = 0;
			//break;
		}
		else
		{
			dataBuffer_R[count++]= receive_Data;
		}


		//HAL_UART_Transmit(&terminal_UART, (uint8_t*)dataBuffer_R, count, HAL_MAX_DELAY);


	}

//	while(reception_Count != 1)
//	{
//		HAL_UART_Receive_IT(&terminal_UART, &receive_Data, 1);
//	}

    while(1);
	return 0;

}

void SystemClockConfig(void)
{
  //ToBeDefined
};

void UART2_Init(void)
{
	terminal_UART.Instance 				= USART2;
	terminal_UART.Init.BaudRate			= 115200;
	terminal_UART.Init.WordLength 		= 0x00000000U;
	terminal_UART.Init.StopBits			= UART_STOPBITS_1;
	terminal_UART.Init.Parity			= UART_PARITY_NONE;
	terminal_UART.Init.Mode				= UART_MODE_TX_RX;
	terminal_UART.Init.HwFlowCtl		= UART_HWCONTROL_NONE;

	if(HAL_UART_Init(&terminal_UART) != HAL_OK)
	{
		while(1); //Error Handler
	}
}

void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(receive_Data == '\r')
	{
		reception_Count=1;
		dataBuffer_R[count++] = '\r';
		HAL_UART_Transmit(&terminal_UART, (uint8_t*)dataBuffer_R, count, HAL_MAX_DELAY);
	}
	else
	{
		dataBuffer_R[count++]= receive_Data;
	}

}
