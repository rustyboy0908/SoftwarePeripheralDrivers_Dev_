/*
 * app_uart.c
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */

//#include "app_uart.h"
//#include "stm32g0xx_hal_def.h"

#include "boilerPlateHeader.h"

//void UART2_Init(void)
//{
//	terminal_UART.Instance 				= USART2;
//	terminal_UART.Init.BaudRate			= 115200;
//	terminal_UART.Init.WordLength 		= 0x00000000U;
//	terminal_UART.Init.StopBits			= UART_STOPBITS_1;
//	terminal_UART.Init.Parity			= UART_PARITY_NONE;
//	terminal_UART.Init.Mode				= UART_MODE_TX_RX;
//	terminal_UART.Init.HwFlowCtl		= UART_HWCONTROL_NONE;
//
//	if(HAL_UART_Init(&terminal_UART) != HAL_OK)
//	{
//		while(1); //Error Handler
//	}
//
//
//}
