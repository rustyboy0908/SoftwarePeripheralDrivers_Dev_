/*
 * boilerPlateHeader.h
 *
 *  Created on: Sep 28, 2024
 *      Author: Rishabh.Srivastava
 */

#ifndef INC_BOILERPLATEHEADER_H_
#define INC_BOILERPLATEHEADER_H_

#include "stm32g0xx.h"
#include "string.h"
#include "stdio.h"

#include "stm32g0xx_hal_uart.h"
#include "stm32g071xx.h"



/*Peripheral Specific - Application app_uart.h*/

//UART_HandleTypeDef terminal_UART;

//void UART2_Init(void);




#endif /* INC_BOILERPLATEHEADER_H_ */
